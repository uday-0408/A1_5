/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./chatapp/templates/**/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}